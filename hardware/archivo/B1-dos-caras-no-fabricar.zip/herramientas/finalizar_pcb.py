#!/usr/bin/env python3
"""Normaliza campos KiCad 10, anchos de pista y conexión térmica; ejecutar tras generar PCB."""
from pathlib import Path
import os
os.chdir(Path(__file__).resolve().parents[1])
import sys
sys.path.insert(0,'herramientas')
import pcbnew,circuito
b=pcbnew.LoadBoard('hardware/ecualizador.kicad_pcb');mm=pcbnew.FromMM
for t in b.GetTracks():
 if t.Type()==pcbnew.PCB_TRACE_T and t.GetWidth()<mm(.25):t.SetWidth(mm(.25))
for f in b.GetFootprints():
 try:p=circuito.pieza(f.GetReference())
 except StopIteration:continue
 f.GetField(pcbnew.FIELD_T_DESCRIPTION).SetText(p['funcion'])
 f.Value().SetVisible(False)
 # Reference stays on fabrication drawing; silkscreen keeps functional labels.
 f.Reference().SetLayer(pcbnew.F_Fab)
 for pad in f.Pads():
  if f.GetReference()=='C1' and pad.GetNumber()=='2':pad.SetLocalZoneConnection(pcbnew.ZONE_CONNECTION_FULL)
for d in b.GetDrawings():
 if d.GetLayer()==pcbnew.F_SilkS and ((d.Type()==pcbnew.PCB_SHAPE_T and 20<pcbnew.ToMM(d.GetPosition().x)<80) or (d.Type()==pcbnew.PCB_TEXT_T and 'WAVESHARE' in d.GetText())):d.SetLayer(pcbnew.F_Fab)
t=b.GetTitleBlock();t.SetTitle('Ecualizador ESP32 - Waveshare 1.9 - NeoPixel');t.SetRevision('B.1');t.SetDate('2026-10-22');t.SetCompany('CUC - Electronica II')
for d in list(b.GetDrawings()):
 if d.Type()==pcbnew.PCB_TEXT_T and 'PCB REV' in d.GetText():b.Remove(d)
txt=pcbnew.PCB_TEXT(b);txt.SetText('PCB REV B.1 | 200 x 120 mm | 2 CAPAS');txt.SetPosition(pcbnew.VECTOR2I(mm(100),mm(115)));txt.SetTextSize(pcbnew.VECTOR2I(mm(1.2),mm(1.2)));txt.SetLayer(pcbnew.F_Fab);b.Add(txt)
b.BuildConnectivity();pcbnew.ZONE_FILLER(b).Fill(b.Zones());b.Save('hardware/ecualizador.kicad_pcb')
